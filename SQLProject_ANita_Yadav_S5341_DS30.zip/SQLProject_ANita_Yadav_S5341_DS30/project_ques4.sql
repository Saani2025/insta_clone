use mavenmovies;


select title from film

join film_actor on film.film_id=film_actor.film_id

join actor on film_actor.actor_id=actor.actor_id

and first_name='Will';

