use mavenmovies;

select * from actor;

select length(first_name) as name_length from actor limit 10;