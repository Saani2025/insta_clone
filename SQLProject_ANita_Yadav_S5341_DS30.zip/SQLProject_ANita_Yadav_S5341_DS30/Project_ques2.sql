use mavenmovies;

select *  from actor_award;

select awards, concat(first_name,' ',last_name) as full_name, length(concat(first_name, last_name)) as name_length from actor_award where awards like 'O%';
