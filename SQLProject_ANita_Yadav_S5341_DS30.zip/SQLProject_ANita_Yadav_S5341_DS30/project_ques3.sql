use mavenmovies;

select first_name, last_name from actor

join film_actor on actor.actor_id=film_actor.actor_id

join film on film_actor.film_id=film.film_id

and film.title='Frost Head';
